#include <iostream>
#include <cstdint>
#include <vector>
#include <cmath>
#include "Vector3.h"
using namespace std;

class Face
{
public:
	uint32_t ix1;
	uint32_t ix2;
	uint32_t ix3;
	// j�senfunktio joka laskee kolmion pinta-alan
	float CountArea(const Face& face, vector<Vertex> vertexes)
	{
		float s1;
		float s2;
		float s3;

		s1 = vertexes[(face.ix1 - 1)].Magnitude(vertexes[(face.ix1 - 1)]);
		s2 = vertexes[(face.ix2 - 1)].Magnitude(vertexes[(face.ix2 - 1)]);
		s3 = vertexes[(face.ix3 - 1)].Magnitude(vertexes[(face.ix3 - 1)]);
		//cout << s1 << ", " << s2 << ", " << s2 << "\n";
		return (sqrt((s1 + s2 + s3) * (s1 + s2 - s3) * (s2 + s3 - s1) * (s3 + s1 - s2)) / 4);
	}
};